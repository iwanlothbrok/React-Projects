﻿public class ProductPropertyDtoExport
{
    public string Name { get; set; }
    public string Value { get; set; }
}