﻿using System.Collections.Generic;

public class BrandDtoExport
{
    public string Name { get; set; }
    public List<ProductDtoExport> Products { get; set; }
}